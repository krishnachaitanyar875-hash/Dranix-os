# DranixOS — How to Open and Run

## What is inside this folder?

```
DranixOS/
│
├── app/                ← Android Studio project (open this)
│   └── src/main/java/com/dranix/
│       ├── MainActivity.kt          ← Main screen
│       ├── island/DranixIsland.kt   ← Dynamic Island
│       ├── ai/DranixAI.kt           ← On-device AI
│       ├── assistant/               ← Full AI assistant screen
│       ├── store/                   ← DranixStore
│       └── settings/                ← ROM settings
│
├── rom/                ← ROM source files (for building flashable ROM)
│   └── ...
│
└── .github/workflows/
    └── build.yml       ← GitHub auto-builder (builds flashable ROM free)
```

---

## Step 1 — Install Android Studio

Go to: **developer.android.com/studio**
Download and install it. It is free.

---

## Step 2 — Open DranixOS in Android Studio

1. Open Android Studio
2. Click **Open**
3. Select the **DranixOS** folder
4. Wait for it to load (2-3 minutes first time)

---

## Step 3 — Run on Emulator

1. Click **Device Manager** (top right)
2. Click **Create Device**
3. Select **Pixel 6** → Next
4. Select **Android 14** → Next → Finish
5. Press the **▶ Play button**
6. DranixOS app opens in the virtual phone

---

## Step 4 — Run on Your Real Phone

1. Connect your Redmi Note 9 Pro Max with USB cable
2. Enable **Developer Options** on phone:
   - Go to Settings → About Phone
   - Tap **MIUI Version** 7 times
   - Go back → Additional Settings → Developer Options
   - Turn on **USB Debugging**
3. Press the **▶ Play button** in Android Studio
4. Select your phone
5. DranixOS installs and opens!

---

## Step 5 — Build Flashable ROM (Free on GitHub)

1. Create account on **github.com**
2. Create new repository named **DranixOS**
3. Upload all files from the **DranixOS** folder
4. Go to **Actions** tab
5. Click **DranixOS ROM Builder**
6. Click **Run workflow**
7. Wait 3-4 hours
8. Download the ZIP from **Artifacts**
9. Flash with TWRP!

---

## What DranixOS App Shows You

| Feature | How to test |
|---------|------------|
| Dynamic Island | Tap any button on main screen |
| AI Chat | Type anything in the chat box |
| Lock phone command | Type: lock phone |
| Set timer | Type: set 5 min timer |
| DranixStore | Tap Store button |
| Settings | Tap Settings button |
| Full AI | Tap AI button |

---

## Commands DranixAI Understands

```
lock phone          → Locks your phone
set 5 min timer     → Sets a 5 minute timer
play music          → Shows music in Dynamic Island
open store          → Opens DranixStore
what time is it     → Tells current time
tell me a joke      → Tells a joke
motivate me         → Gives motivation
what can you do     → Shows all features
```

---

Made by krishnachaitanyar875 with ❤️
DranixOS v1.0 OFFICIAL — Redmi Note 9 Pro Max
