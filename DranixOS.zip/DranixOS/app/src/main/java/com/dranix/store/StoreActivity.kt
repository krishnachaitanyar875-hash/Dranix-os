package com.dranix.store

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StoreActivity : AppCompatActivity() {

    data class App(val icon:String, val name:String, val category:String, val url:String)

    private val apps = listOf(
        App("📷","Camera","Photography","https://play.google.com/store/apps/details?id=com.google.android.GoogleCamera"),
        App("🎵","Spotify","Music","https://play.google.com/store/apps/details?id=com.spotify.music"),
        App("🎮","PUBG Mobile","Gaming","https://play.google.com/store/apps/details?id=com.tencent.ig"),
        App("📱","Instagram","Social","https://play.google.com/store/apps/details?id=com.instagram.android"),
        App("🎬","YouTube","Video","https://play.google.com/store/apps/details?id=com.google.android.youtube"),
        App("💬","WhatsApp","Messaging","https://play.google.com/store/apps/details?id=com.whatsapp"),
        App("🗺","Google Maps","Navigation","https://play.google.com/store/apps/details?id=com.google.android.apps.maps"),
        App("📸","Snapchat","Social","https://play.google.com/store/apps/details?id=com.snapchat.android"),
        App("🎧","YouTube Music","Music","https://play.google.com/store/apps/details?id=com.google.android.apps.youtube.music"),
        App("🛒","Amazon","Shopping","https://play.google.com/store/apps/details?id=com.amazon.mShop.android.shopping"),
        App("💳","Google Pay","Finance","https://play.google.com/store/apps/details?id=com.google.android.apps.nbu.paisa.user"),
        App("🎯","Free Fire","Gaming","https://play.google.com/store/apps/details?id=com.dts.freefireth"),
        App("📰","Inshorts","News","https://play.google.com/store/apps/details?id=com.nis.app"),
        App("🎓","Duolingo","Education","https://play.google.com/store/apps/details?id=com.duolingo"),
        App("🏃","Google Fit","Health","https://play.google.com/store/apps/details?id=com.google.android.apps.fitness")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt()
        setContentView(buildUI())
    }

    private fun buildUI(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050508.toInt())
            layoutParams = ViewGroup.LayoutParams(-1,-1)
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(14),dp(14),dp(14),dp(14))
        }
        TextView(this).apply { text="← Back"; setTextColor(0xFF7C3AED.toInt()); textSize=14f; setOnClickListener{finish()}; header.addView(this) }
        TextView(this).apply { text="  🏪 DranixStore"; setTextColor(0xFFFFFFFF.toInt()); textSize=16f; typeface=android.graphics.Typeface.DEFAULT_BOLD; header.addView(this) }
        root.addView(header)

        TextView(this).apply {
            text = "Tap any app to install from Play Store"
            setTextColor(0xFF666688.toInt()); textSize=11f; setPadding(dp(14),dp(8),dp(14),dp(4))
            root.addView(this)
        }

        // Search bar
        val search = EditText(this).apply {
            hint = "🔍 Search apps..."; textSize=13f
            setHintTextColor(0xFF444466.toInt()); setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A2E.toInt())
            setPadding(dp(14),dp(10),dp(14),dp(10))
            layoutParams = LinearLayout.LayoutParams(-1,-2).apply { setMargins(dp(12),dp(8),dp(12),dp(8)) }
        }
        root.addView(search)

        // App grid
        val scroll = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1,0,1f) }
        val grid = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(8),0,dp(8),dp(16)) }

        // Two columns
        var rowLayout: LinearLayout? = null
        apps.forEachIndexed { idx, app ->
            if (idx % 2 == 0) {
                rowLayout = LinearLayout(this).apply {
                    orientation=LinearLayout.HORIZONTAL
                    layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)}
                }
                grid.addView(rowLayout)
            }
            rowLayout?.addView(buildAppCard(app))
        }

        scroll.addView(grid); root.addView(scroll)
        return root
    }

    private fun buildAppCard(app: App): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(12),dp(14),dp(12),dp(14))
            layoutParams = LinearLayout.LayoutParams(0,-2,1f).apply { setMargins(dp(4),0,dp(4),0) }
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(app.url)).apply {
                    setPackage("com.android.vending")
                }.let { intent ->
                    if (intent.resolveActivity(packageManager) != null) intent
                    else Intent(Intent.ACTION_VIEW, Uri.parse(app.url))
                })
            }
        }
        TextView(this).apply { text=app.icon; textSize=32f; gravity=android.view.Gravity.CENTER; card.addView(this) }
        TextView(this).apply { text=app.name; textSize=13f; setTextColor(0xFFFFFFFF.toInt()); gravity=android.view.Gravity.CENTER; card.addView(this) }
        TextView(this).apply { text=app.category; textSize=10f; setTextColor(0xFF666688.toInt()); gravity=android.view.Gravity.CENTER; card.addView(this) }
        Button(this).apply {
            text="Install"; textSize=11f
            setBackgroundColor(0xFF7C3AED.toInt()); setTextColor(0xFFFFFFFF.toInt())
            layoutParams=LinearLayout.LayoutParams(-1,dp(32)).apply{topMargin=dp(8)}
            setOnClickListener { card.callOnClick() }
            card.addView(this)
        }
        return card
    }

    private fun dp(v:Int) = (v*resources.displayMetrics.density).toInt()
}
