package com.dranix.settings

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DranixSettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt()
        setContentView(buildUI())
    }

    private fun buildUI(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050508.toInt())
            layoutParams = ViewGroup.LayoutParams(-1,-1)
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(14),dp(14),dp(14),dp(14))
        }
        TextView(this).apply { text="← Back"; setTextColor(0xFF7C3AED.toInt()); textSize=14f; setOnClickListener{finish()}; header.addView(this) }
        TextView(this).apply { text="  ⚙️ DranixOS Settings"; setTextColor(0xFFFFFFFF.toInt()); textSize=16f; typeface=android.graphics.Typeface.DEFAULT_BOLD; header.addView(this) }
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(20)) }

        // ROM info card
        content.addView(infoCard())

        // Settings toggles
        val settings = listOf(
            Triple("🏝️ Dynamic Island",      "Show live activities in pill",           true),
            Triple("🤖 DranixAI",            "On-device AI assistant",                 true),
            Triple("🎮 Gaming Mode",          "Boost performance for games",            false),
            Triple("📺 Always on Display",    "Show clock when screen is off",          false),
            Triple("🔐 Face Unlock",          "Unlock with face",                       true),
            Triple("🍎 iOS Theme",            "iPhone-style icons and animations",      true),
            Triple("🌙 Dark Mode",            "Dark background everywhere",             true),
            Triple("⚡ Fast Charging HUD",    "Show charging info in island",           true),
            Triple("🔇 Smart Mute",           "Auto-mute in meetings",                  false),
            Triple("📍 Smart Location",       "AI-powered location suggestions",        false),
            Triple("🔋 Battery Optimizer",    "AI manages battery life",                true),
            Triple("📊 RAM Booster",          "Clear background apps automatically",    false)
        )

        settings.forEach { (title, desc, default) ->
            content.addView(buildToggleRow(title, desc, default))
        }

        scroll.addView(content); root.addView(scroll)
        return root
    }

    private fun infoCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(16),dp(16),dp(16),dp(16))
            layoutParams = LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(16) }
        }
        TextView(this).apply { text="⬡ DranixOS v1.0 OFFICIAL"; setTextColor(0xFF7C3AED.toInt()); textSize=15f; typeface=android.graphics.Typeface.DEFAULT_BOLD; card.addView(this) }
        TextView(this).apply { text="Device: Redmi Note 9 Pro Max"; setTextColor(0xFF888899.toInt()); textSize=12f; card.addView(this) }
        TextView(this).apply { text="Maintainer: krishnachaitanyar875"; setTextColor(0xFF888899.toInt()); textSize=12f; card.addView(this) }
        TextView(this).apply { text="Android 14 base | Built with ❤️"; setTextColor(0xFF888899.toInt()); textSize=12f; card.addView(this) }
        return card
    }

    private fun buildToggleRow(title: String, desc: String, default: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14),dp(14),dp(14),dp(14))
            setBackgroundColor(0xFF0D0D18.toInt())
            layoutParams = LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(2) }
        }
        val textCol = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        }
        TextView(this).apply { text=title; setTextColor(0xFFFFFFFF.toInt()); textSize=13f; typeface=android.graphics.Typeface.DEFAULT_BOLD; textCol.addView(this) }
        TextView(this).apply { text=desc; setTextColor(0xFF666688.toInt()); textSize=11f; textCol.addView(this) }
        row.addView(textCol)
        Switch(this).apply {
            isChecked=default
            thumbTintList = android.content.res.ColorStateList.valueOf(if(default) 0xFF7C3AED.toInt() else 0xFF333355.toInt())
            setOnCheckedChangeListener { _, checked ->
                thumbTintList = android.content.res.ColorStateList.valueOf(if(checked) 0xFF7C3AED.toInt() else 0xFF333355.toInt())
                Toast.makeText(context, "$title ${if(checked)"enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
            }
            row.addView(this)
        }
        return row
    }

    private fun dp(v:Int) = (v*resources.displayMetrics.density).toInt()
}
