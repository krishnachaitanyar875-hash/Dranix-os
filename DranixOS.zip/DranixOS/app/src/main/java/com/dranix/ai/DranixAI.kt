package com.dranix.ai

import android.content.Context
import kotlinx.coroutines.delay
import java.util.Calendar

class DranixAI(private val context: Context) {

    private val hour get() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    private val history = mutableListOf<Pair<String,String>>()

    suspend fun respond(input: String): String {
        delay(600) // simulate thinking
        val q = input.lowercase().trim()
        history.add(Pair("user", input))

        val response = when {
            // ── Greetings ──────────────────────────────────────────
            q.matches(Regex(".*(hi|hello|hey|namaste).*")) ->
                greeting()

            // ── Identity ───────────────────────────────────────────
            q.contains("who are you") || q.contains("what are you") ->
                "I am DranixAI, the built-in AI assistant of DranixOS. " +
                "I run fully on your device — no internet needed. " +
                "I was built by krishnachaitanyar875 for the Redmi Note 9 Pro Max."

            q.contains("your name") ->
                "My name is DranixAI. I am the official AI of DranixOS!"

            // ── About the ROM ──────────────────────────────────────
            q.contains("dranix") || q.contains("rom") || q.contains("os") ->
                "DranixOS is a custom Android ROM built for Redmi Note 9 Pro Max. " +
                "Features: Dynamic Island, on-device AI (me!), iOS-style theme, " +
                "built-in app store, gaming mode, face unlock, and much more. " +
                "Developer: krishnachaitanyar875"

            // ── Time ───────────────────────────────────────────────
            q.contains("time") || q.contains("what time") ->
                "It is ${java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())}."

            q.contains("date") || q.contains("today") ->
                "Today is ${java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())}."

            // ── Weather (offline fallback) ─────────────────────────
            q.contains("weather") ->
                "I am running offline so I cannot check live weather. " +
                "Connect to internet and I will fetch it for you!"

            // ── Math ───────────────────────────────────────────────
            q.matches(Regex(".*\\d+\\s*[+\\-*/]\\s*\\d+.*")) ->
                solveMath(q)

            // ── Motivational ───────────────────────────────────────
            q.contains("motivat") || q.contains("inspire") || q.contains("sad") ->
                motivate()

            // ── Jokes ──────────────────────────────────────────────
            q.contains("joke") || q.contains("funny") ->
                joke()

            // ── Battery ────────────────────────────────────────────
            q.contains("battery") ->
                "I can show your battery in the Dynamic Island! Tap ⚡ Charging button above."

            // ── Thank you ──────────────────────────────────────────
            q.contains("thank") ->
                "You are welcome! I am always here to help. 😊"

            // ── Capabilities ───────────────────────────────────────
            q.contains("can you") || q.contains("what can") ->
                "I can:\n• Answer questions\n• Lock/unlock your phone\n• Set timers\n" +
                "• Control music\n• Do math\n• Tell jokes\n• Open apps\n• Enable hotspot\n" +
                "• Start screen recording\n• Show live info in Dynamic Island\n\nJust ask!"

            // ── Default smart response ─────────────────────────────
            else -> smartFallback(input)

        }.also { history.add(Pair("ai", it)) }

        return response
    }

    private fun greeting(): String {
        val timeGreet = when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else      -> "Good evening"
        }
        return "$timeGreet, Krishna! I am DranixAI. How can I help you today? 😊"
    }

    private fun solveMath(q: String): String {
        return try {
            val expr = Regex("(\\d+)\\s*([+\\-*/])\\s*(\\d+)").find(q)
            if (expr != null) {
                val a = expr.groupValues[1].toDouble()
                val op = expr.groupValues[2]
                val b = expr.groupValues[3].toDouble()
                val result = when(op) {
                    "+" -> a + b; "-" -> a - b
                    "*" -> a * b; "/" -> if (b != 0.0) a / b else Double.NaN
                    else -> Double.NaN
                }
                if (result.isNaN()) "Cannot divide by zero!"
                else "The answer is ${if(result == result.toLong().toDouble()) result.toLong() else result}"
            } else "I could not solve that math problem."
        } catch (e: Exception) { "I could not solve that." }
    }

    private fun motivate(): String {
        val quotes = listOf(
            "You are stronger than you think, Krishna! Keep going! 💪",
            "Every expert was once a beginner. You are on the right path! 🌟",
            "Believe in yourself. You built DranixOS — you can do anything! 🚀",
            "Success is not final, failure is not fatal. It is the courage to continue! ⭐",
            "You are doing great. One step at a time! 🎯"
        )
        return quotes.random()
    }

    private fun joke(): String {
        val jokes = listOf(
            "Why do programmers prefer dark mode? Because light attracts bugs! 😄",
            "Why did the phone go to school? To improve its cell-f! 📱😂",
            "What did the Android say to iOS? You are jailed! 😆",
            "Why did the computer go to the doctor? Because it had a virus! 💻😷",
            "What do you call a fake noodle? An impasta! 🍝😄"
        )
        return jokes.random()
    }

    private fun smartFallback(input: String): String {
        val responses = listOf(
            "That is an interesting question! In the full DranixOS with internet, " +
            "I would give you a much better answer. For now: $input — noted!",
            "I am still learning, Krishna! Ask me again with more details.",
            "Great question! Connect me to internet for a full answer. " +
            "Offline I know: time, math, phone controls, and ROM info.",
            "I heard you say: '$input'. In the full ROM I will answer this perfectly!"
        )
        return responses.random()
    }
}
