package com.dranix

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dranix.ai.DranixAI
import com.dranix.island.DranixIsland
import com.dranix.assistant.AssistantActivity
import com.dranix.store.StoreActivity
import com.dranix.settings.DranixSettingsActivity
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var island: DranixIsland
    private lateinit var ai: DranixAI
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var inputField: EditText
    private lateinit var statusBar: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF000000.toInt()
        setContentView(buildUI())
        ai = DranixAI(this)
        checkOverlayPermission()
        setupButtons()
    }

    // ── Full UI ───────────────────────────────────────────────────────

    private fun buildUI(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050508.toInt())
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }

        // ── Dynamic Island ─────────────────────────────────────────
        island = DranixIsland(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(130))
            onTap = { showToast("Island tapped!") }
            onLongPress = { startActivity(Intent(this@MainActivity, AssistantActivity::class.java)) }
        }
        root.addView(island)

        // ── Top nav bar ────────────────────────────────────────────
        root.addView(buildNavBar())

        // ── Live activity buttons ──────────────────────────────────
        root.addView(sectionTitle("  LIVE ACTIVITIES"))
        root.addView(buildIslandButtons())

        // ── AI section ────────────────────────────────────────────
        root.addView(sectionTitle("  DRANIX AI — voice & text"))

        // Status
        statusBar = TextView(this).apply {
            text = "● AI ready — type or tap 🎤"
            setTextColor(0xFF7C3AED.toInt()); textSize = 11f
            setPadding(dp(14), dp(4), dp(14), dp(4))
        }
        root.addView(statusBar)

        // Chat area
        chatScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        chatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        addAIBubble("Hello Krishna! I am DranixAI. I can:\n" +
            "• Answer anything\n• Lock or unlock your phone\n" +
            "• Set timers\n• Control music\n• Open any app\n\nTry: 'lock phone' or 'set 5 min timer'")
        chatScroll.addView(chatBox)
        root.addView(chatScroll)

        // Input
        root.addView(buildInputBar())

        return root
    }

    private fun buildNavBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        listOf(
            "🏠 Home"     to null,
            "🤖 AI"       to AssistantActivity::class.java,
            "🏪 Store"    to StoreActivity::class.java,
            "⚙️ Settings" to DranixSettingsActivity::class.java
        ).forEach { (label, cls) ->
            Button(this).apply {
                text = label; textSize = 10f
                setBackgroundColor(0xFF1A1A2E.toInt())
                setTextColor(0xFFCCCCFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(3),0,dp(3),0) }
                setOnClickListener { cls?.let { startActivity(Intent(this@MainActivity, it)) } }
                bar.addView(this)
            }
        }
        return bar
    }

    private fun buildIslandButtons(): View {
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }

        fun row(vararg pairs: Pair<String, () -> Unit>): LinearLayout {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
            }
            pairs.forEach { (label, action) ->
                Button(this).apply {
                    text = label; textSize = 11f
                    setBackgroundColor(0xFF1A1A2E.toInt())
                    setTextColor(0xFFFFFFFF.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3),0,dp(3),0) }
                    setOnClickListener { action() }
                    row.addView(this)
                }
            }
            return row
        }

        grid.addView(row(
            "📞 Call"    to { island.showCall("Priya Sharma") },
            "🎵 Music"   to { island.showMedia("Blinding Lights","The Weeknd") },
            "⚡ Charging" to { island.showCharging(78, 33f) }
        ))
        grid.addView(row(
            "⏱ Timer"    to { island.showTimer(300L, "Workout") },
            "🔴 Record"   to { island.showRecord() },
            "📡 Hotspot"  to { island.showHotspot(2) }
        ))
        grid.addView(row(
            "🗺 Navigate" to { island.showNav("Turn left", "200m") },
            "🤖 AI Reply" to { island.showAI("Sure! I can help with that.") },
            "○ Idle"      to { island.idle() }
        ))
        return grid
    }

    private fun buildInputBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        inputField = EditText(this).apply {
            hint = "Ask DranixAI anything..."; textSize = 13f
            setHintTextColor(0xFF444466.toInt()); setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A2E.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        // Voice button
        Button(this).apply {
            text = "🎤"; textSize = 16f
            setBackgroundColor(0xFF1A1A2E.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(4) }
            setOnClickListener { processVoiceCommand() }
            bar.addView(inputField); bar.addView(this)
        }
        // Send button
        Button(this).apply {
            text = "Send"; textSize = 12f
            setBackgroundColor(0xFF7C3AED.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(44)).apply { leftMargin = dp(4) }
            setOnClickListener { sendMessage() }
            bar.addView(this)
        }
        return bar
    }

    // ── AI logic ──────────────────────────────────────────────────────

    private fun sendMessage() {
        val msg = inputField.text.toString().trim()
        if (msg.isEmpty()) return
        inputField.setText("")
        addUserBubble(msg)
        processCommand(msg)
    }

    private fun processCommand(input: String) {
        val cmd = input.lowercase().trim()
        statusBar.text = "● DranixAI thinking..."
        island.showAIThinking()

        lifecycleScope.launch {
            val response = withContext(Dispatchers.Default) {
                when {
                    // ── Phone lock/unlock commands ─────────────────
                    cmd.contains("lock") && cmd.contains("phone") -> {
                        triggerLock()
                        "Phone locked. 🔒"
                    }
                    cmd.contains("unlock") && cmd.contains("phone") -> {
                        "Unlock command sent. 🔓 (Requires accessibility service in full ROM)"
                    }
                    // ── Timer commands ─────────────────────────────
                    cmd.contains("timer") -> {
                        val num = Regex("\\d+").find(cmd)?.value?.toLong() ?: 5L
                        val unit = if (cmd.contains("sec")) num else num * 60
                        island.showTimer(unit, "DranixAI Timer")
                        "Timer set for $num ${if(cmd.contains("sec")) "seconds" else "minutes"}! ⏱"
                    }
                    // ── Music commands ─────────────────────────────
                    cmd.contains("play") || cmd.contains("music") -> {
                        island.showMedia("Now Playing", "DranixAI picked this")
                        "Playing music! 🎵"
                    }
                    cmd.contains("pause") || cmd.contains("stop music") -> {
                        island.idle()
                        "Music paused. ⏸"
                    }
                    // ── App open commands ──────────────────────────
                    cmd.contains("open") && cmd.contains("store") -> {
                        startActivity(Intent(this@MainActivity, StoreActivity::class.java))
                        "Opening DranixStore! 🏪"
                    }
                    cmd.contains("open") && cmd.contains("settings") -> {
                        startActivity(Intent(this@MainActivity, DranixSettingsActivity::class.java))
                        "Opening Settings! ⚙️"
                    }
                    // ── Hotspot commands ───────────────────────────
                    cmd.contains("hotspot") -> {
                        island.showHotspot(0)
                        "Hotspot enabled! 📡"
                    }
                    // ── Screen record ──────────────────────────────
                    cmd.contains("record") || cmd.contains("screen") -> {
                        island.showRecord()
                        "Screen recording started! 🔴"
                    }
                    // ── What can you do ────────────────────────────
                    cmd.contains("what can you do") || cmd.contains("help") -> {
                        "I can:\n🔒 Lock/unlock phone\n⏱ Set timers\n🎵 Control music\n📱 Open apps\n📡 Enable hotspot\n🔴 Record screen\n💬 Answer questions\n\nJust tell me what you need!"
                    }
                    // ── General AI response ────────────────────────
                    else -> ai.respond(input)
                }
            }
            delay(200)
            addAIBubble(response)
            island.showAI(response.take(55))
            statusBar.text = "● AI ready — type or tap 🎤"
            scrollDown()
        }
    }

    private fun processVoiceCommand() {
        addAIBubble("Voice input coming in full ROM! For now type your command.")
        showToast("Voice control active in full DranixOS ROM")
    }

    private fun triggerLock() {
        val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
        try { dpm?.lockNow() } catch (e: Exception) {
            showToast("Lock requires Device Admin permission in full ROM")
        }
    }

    // ── Chat bubbles ──────────────────────────────────────────────────

    private fun addUserBubble(text: String) {
        TextView(this).apply {
            this.text = "You: $text"; textSize = 13f
            setTextColor(0xFFCCCCFF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFF1A1A3E.toInt())
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply {
                gravity = android.view.Gravity.END
                topMargin = dp(6); bottomMargin = dp(2)
                leftMargin = dp(50)
            }
            chatBox.addView(this)
        }
        scrollDown()
    }

    private fun addAIBubble(text: String) {
        TextView(this).apply {
            this.text = "🤖 DranixAI: $text"; textSize = 13f
            setTextColor(0xFFE0E0FF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFF12122A.toInt())
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply {
                gravity = android.view.Gravity.START
                topMargin = dp(2); bottomMargin = dp(6)
                rightMargin = dp(50)
            }
            chatBox.addView(this)
        }
        scrollDown()
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text; textSize = 10f
        setTextColor(0xFF444466.toInt())
        setPadding(dp(14), dp(10), dp(14), dp(4))
    }

    private fun setupButtons() {}
    private fun scrollDown() { chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) } }
    private fun showToast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
