package com.dranix.assistant

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dranix.ai.DranixAI
import kotlinx.coroutines.*

class AssistantActivity : AppCompatActivity() {

    private lateinit var ai: DranixAI
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var inputField: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt()
        setContentView(buildUI())
        ai = DranixAI(this)
        addAIBubble("Hey Krishna! I am DranixAI. Ask me anything — I am fully on-device, no internet needed! 🤖")
    }

    private fun buildUI(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF050508.toInt())
            layoutParams = ViewGroup.LayoutParams(-1,-1)
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(14),dp(14),dp(14),dp(14))
        }
        TextView(this).apply {
            text = "← Back"; setTextColor(0xFF7C3AED.toInt()); textSize = 14f
            setOnClickListener { finish() }
            header.addView(this)
        }
        TextView(this).apply {
            text = "  ⬡ DranixAI Assistant"; setTextColor(Color.WHITE); textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            header.addView(this)
        }
        root.addView(header)

        // Status
        statusText = TextView(this).apply {
            text = "● On-device AI · No internet needed"
            setTextColor(0xFF7C3AED.toInt()); textSize = 11f
            setPadding(dp(14),dp(8),dp(14),dp(4))
        }
        root.addView(statusText)

        // Quick commands
        root.addView(buildQuickCommands())

        // Chat
        chatScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1,0,1f)
        }
        chatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12),dp(8),dp(12),dp(8))
        }
        chatScroll.addView(chatBox)
        root.addView(chatScroll)

        // Input
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0D0D18.toInt())
            setPadding(dp(10),dp(8),dp(10),dp(8))
        }
        inputField = EditText(this).apply {
            hint = "Ask anything..."; textSize = 13f
            setHintTextColor(0xFF444466.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1A1A2E.toInt())
            setPadding(dp(12),dp(10),dp(12),dp(10))
            layoutParams = LinearLayout.LayoutParams(0,-2,1f)
        }
        Button(this).apply {
            text = "Send"; setBackgroundColor(0xFF7C3AED.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(70),dp(44)).apply { leftMargin = dp(6) }
            setOnClickListener { send() }
            inputRow.addView(inputField); inputRow.addView(this)
        }
        root.addView(inputRow)
        return root
    }

    private fun buildQuickCommands(): View {
        val scroll = android.widget.HorizontalScrollView(this).apply {
            setPadding(dp(10),dp(6),dp(10),dp(6))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("What time is it?","Tell me a joke","Motivate me",
               "What can you do?","Lock phone","Set 5 min timer").forEach { cmd ->
            Button(this).apply {
                text = cmd; textSize = 11f
                setBackgroundColor(0xFF1A1A2E.toInt())
                setTextColor(0xFFCCCCFF.toInt())
                layoutParams = LinearLayout.LayoutParams(-2, dp(34)).apply { rightMargin = dp(6) }
                setOnClickListener { inputField.setText(cmd); send() }
                row.addView(this)
            }
        }
        scroll.addView(row)
        return scroll
    }

    private fun send() {
        val msg = inputField.text.toString().trim()
        if (msg.isEmpty()) return
        inputField.setText("")
        addUserBubble(msg)
        statusText.text = "● DranixAI thinking..."
        lifecycleScope.launch {
            val resp = withContext(Dispatchers.Default) { ai.respond(msg) }
            addAIBubble(resp)
            statusText.text = "● On-device AI · No internet needed"
            chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun addUserBubble(text: String) {
        TextView(this).apply {
            this.text = "You: $text"; textSize = 13f
            setTextColor(0xFFCCCCFF.toInt())
            setBackgroundColor(0xFF1A1A3E.toInt())
            setPadding(dp(12),dp(8),dp(12),dp(8))
            layoutParams = LinearLayout.LayoutParams(-2,-2).apply {
                gravity = android.view.Gravity.END
                topMargin=dp(6); leftMargin=dp(50)
            }
            chatBox.addView(this)
        }
    }

    private fun addAIBubble(text: String) {
        TextView(this).apply {
            this.text = "🤖 $text"; textSize = 13f
            setTextColor(0xFFE0E0FF.toInt())
            setBackgroundColor(0xFF12122A.toInt())
            setPadding(dp(12),dp(8),dp(12),dp(8))
            layoutParams = LinearLayout.LayoutParams(-2,-2).apply {
                gravity = android.view.Gravity.START
                topMargin=dp(6); rightMargin=dp(50)
            }
            chatBox.addView(this)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val Color = android.graphics.Color
}
