package com.dranix.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.*

class DranixIsland @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    enum class Mode { IDLE, CALL, MEDIA, CHARGING, TIMER, RECORD, AI, AI_THINKING, HOTSPOT, NAV }
    private var mode = Mode.IDLE

    // Geometry
    private var pW = dp(126f); private var pH = dp(37f); private var cAlpha = 0f
    private val rect = RectF()

    // Data
    private var caller=""; private var callPhase=0f
    private var track=""; private var artist=""; private var wavePhase=0f
    private var battery=0; private var watts=0f; private var chargePhase=0f
    private var timerS=0L; private var timerTotal=1L; private var timerLbl=""
    private var recS=0; private var recDot=true
    private var aiTxt=""; private var aiTyped=""; private var aiIdx=0; private var aiPhase=0f
    private var hotDevices=0
    private var navStep=""; private var navDist=""
    private var glowC = Color.parseColor("#00D4FF")

    // Paints
    private val bg    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val glow  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.FILL; maskFilter=BlurMaskFilter(dp(14f),BlurMaskFilter.Blur.NORMAL) }
    private val tp    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; textSize=sp(13f); typeface=Typeface.DEFAULT_BOLD }
    private val sp2   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.parseColor("#AAAAAA"); textSize=sp(11f) }
    private val ap    = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.FILL }
    private val sk    = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE; strokeWidth=dp(3f); strokeCap=Paint.Cap.ROUND }

    // Ticker
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            callPhase+=0.22f; wavePhase+=0.18f; chargePhase+=0.06f; aiPhase+=0.12f
            if (mode==Mode.TIMER && timerS>0) timerS--
            if (mode==Mode.RECORD) { recS++; recDot=!recDot }
            if (mode==Mode.AI && aiIdx<aiTxt.length) aiTyped=aiTxt.substring(0,++aiIdx)
            invalidate(); h.postDelayed(this,80)
        }
    }

    // Gesture
    var onTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null
    private val gd = GestureDetector(ctx, object:GestureDetector.SimpleOnGestureListener(){
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onLongPress(e: MotionEvent) { onLongPress?.invoke() }
    })

    init { setLayerType(LAYER_TYPE_HARDWARE,null); h.post(tick) }

    // ── Public ────────────────────────────────────────────────────────
    fun idle()                             { mode=Mode.IDLE;       glowC=Color.parseColor("#00D4FF"); ex(dp(126f),dp(37f)) }
    fun showCall(n:String)                 { caller=n; mode=Mode.CALL;    glowC=Color.parseColor("#34C759"); ex(dp(340f),dp(90f)) }
    fun showMedia(t:String,a:String)       { track=t; artist=a; mode=Mode.MEDIA;   glowC=Color.parseColor("#1DB954"); ex(dp(360f),dp(80f)) }
    fun showCharging(p:Int,w:Float)        { battery=p; watts=w; mode=Mode.CHARGING; glowC=Color.parseColor("#FF9F0A"); ex(dp(280f),dp(74f)) }
    fun showTimer(s:Long,l:String)         { timerS=s; timerTotal=s; timerLbl=l; mode=Mode.TIMER; glowC=Color.parseColor("#FF9F0A"); ex(dp(244f),dp(68f)) }
    fun showRecord()                       { recS=0; mode=Mode.RECORD; glowC=Color.parseColor("#FF3B30"); ex(dp(220f),dp(60f)) }
    fun showAI(t:String)                   { aiTxt=t; aiTyped=""; aiIdx=0; mode=Mode.AI; glowC=Color.parseColor("#7C3AED"); ex(dp(340f),dp(60f)) }
    fun showAIThinking()                   { mode=Mode.AI_THINKING; glowC=Color.parseColor("#7C3AED"); ex(dp(200f),dp(56f)) }
    fun showHotspot(d:Int)                 { hotDevices=d; mode=Mode.HOTSPOT; glowC=Color.parseColor("#30B0C7"); ex(dp(220f),dp(62f)) }
    fun showNav(s:String,d:String)         { navStep=s; navDist=d; mode=Mode.NAV; glowC=Color.parseColor("#007AFF"); ex(dp(300f),dp(66f)) }

    // ── Draw ──────────────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        val cx=width/2f; val cy=dp(8f)+pH/2f
        rect.set(cx-pW/2f, cy-pH/2f, cx+pW/2f, cy+pH/2f)
        if (cAlpha>0.2f) {
            glow.color=Color.argb((55*cAlpha).toInt(),Color.red(glowC),Color.green(glowC),Color.blue(glowC))
            canvas.drawRoundRect(RectF(rect.left-dp(6f),rect.top-dp(6f),rect.right+dp(6f),rect.bottom+dp(6f)),dp(26f),dp(26f),glow)
        }
        canvas.drawRoundRect(rect,dp(20f),dp(20f),bg)
        if (cAlpha>0f) {
            canvas.save(); canvas.clipRect(rect)
            canvas.saveLayerAlpha(null,(cAlpha*255).toInt())
            draw2(canvas); canvas.restore()
        }
    }

    private fun draw2(c:Canvas) {
        val b=rect; val cy=b.centerY()
        when(mode) {
            Mode.IDLE -> { ap.color=glowC; c.drawCircle(b.centerX(),cy,dp(4f),ap) }
            Mode.CALL -> {
                ap.color=Color.parseColor("#34C759")
                c.drawCircle(b.left+dp(20f),cy,dp(6f)+(sin(callPhase.toDouble())*dp(3f)).toFloat(),ap)
                tp.textSize=sp(15f); tp.color=Color.WHITE; c.drawText(caller,b.left+dp(36f),cy-dp(5f),tp)
                sp2.textSize=sp(12f); c.drawText("Incoming call",b.left+dp(36f),cy+dp(12f),sp2)
                ap.color=Color.parseColor("#FF3B30"); c.drawCircle(b.right-dp(24f),cy,dp(18f),ap)
                tp.textSize=sp(14f); c.drawText("✕",b.right-dp(29f),cy+dp(5f),tp)
            }
            Mode.MEDIA -> {
                tp.textSize=sp(13f); tp.color=Color.WHITE; c.drawText(track,b.left+dp(14f),cy-dp(4f),tp)
                sp2.textSize=sp(11f); c.drawText(artist,b.left+dp(14f),cy+dp(12f),sp2)
                val bw=dp(3f); val mH=dp(14f); val bs=b.right-dp(82f)
                ap.color=Color.parseColor("#1DB954")
                for(i in 0..4){
                    val hh=mH*(0.35f+0.65f* abs(sin((wavePhase+i*0.9).toDouble()).toFloat()))
                    val bx=bs+i*(bw+dp(2f))
                    c.drawRoundRect(RectF(bx,cy-hh/2f,bx+bw,cy+hh/2f),bw/2f,bw/2f,ap)
                }
                tp.textSize=sp(18f); c.drawText("⏸",b.right-dp(32f),cy+dp(7f),tp)
            }
            Mode.CHARGING -> {
                val ic=when{battery<20->Color.parseColor("#FF3B30");battery<50->Color.parseColor("#FF9F0A");else->Color.parseColor("#34C759")}
                tp.color=ic; tp.textSize=sp(22f); c.drawText("⚡",b.left+dp(14f),cy+dp(8f),tp)
                tp.color=Color.WHITE; tp.textSize=sp(26f); c.drawText("$battery%",b.left+dp(46f),cy+dp(10f),tp)
                sp2.textSize=sp(11f); c.drawText(if(watts>0)"${watts.toInt()}W Fast" else "Charging",b.left+dp(46f),cy+dp(25f),sp2)
                val bl=b.left+dp(14f); val br2=b.right-dp(14f); val bt=b.bottom-dp(9f); val bb=b.bottom-dp(4f)
                ap.color=Color.parseColor("#333333"); c.drawRoundRect(RectF(bl,bt,br2,bb),dp(3f),dp(3f),ap)
                val sh=(0.7f+0.3f* abs(sin(chargePhase.toDouble()).toFloat()))
                ap.color=Color.argb((255*sh).toInt(),Color.red(ic),Color.green(ic),Color.blue(ic))
                c.drawRoundRect(RectF(bl,bt,bl+(br2-bl)*battery/100f,bb),dp(3f),dp(3f),ap)
            }
            Mode.TIMER -> {
                tp.color=Color.parseColor("#FF9F0A"); tp.textSize=sp(20f); c.drawText("⏱",b.left+dp(14f),cy+dp(8f),tp)
                sp2.textSize=sp(11f); c.drawText(timerLbl,b.left+dp(44f),cy-dp(5f),sp2)
                val h2=timerS/3600; val m=(timerS%3600)/60; val s=timerS%60
                tp.color=Color.WHITE; tp.textSize=sp(22f)
                c.drawText(if(h2>0)"%d:%02d:%02d".format(h2,m,s) else "%d:%02d".format(m,s),b.left+dp(44f),cy+dp(14f),tp)
                val ar=RectF(b.right-dp(38f),b.top+dp(8f),b.right-dp(8f),b.bottom-dp(8f))
                sk.color=Color.parseColor("#333333"); c.drawArc(ar,-90f,360f,false,sk)
                sk.color=Color.parseColor("#FF9F0A"); c.drawArc(ar,-90f,360f*timerS/timerTotal.toFloat(),false,sk)
            }
            Mode.RECORD -> {
                if(recDot){ap.color=Color.parseColor("#FF3B30"); c.drawCircle(b.left+dp(20f),cy,dp(7f),ap)}
                tp.color=Color.WHITE; tp.textSize=sp(13f); c.drawText("REC",b.left+dp(34f),cy+dp(5f),tp)
                sp2.textSize=sp(13f); c.drawText("%d:%02d".format(recS/60,recS%60),b.left+dp(76f),cy+dp(5f),sp2)
            }
            Mode.AI -> {
                ap.color=Color.parseColor("#7C3AED"); c.drawCircle(b.left+dp(18f),cy,dp(5f),ap)
                tp.color=Color.WHITE; tp.textSize=sp(12f)
                var line=aiTyped; val mxW=b.width()-dp(36f)
                while(tp.measureText(line)>mxW&&line.isNotEmpty()) line=line.dropLast(1)
                c.drawText(line,b.left+dp(30f),cy+dp(5f),tp)
            }
            Mode.AI_THINKING -> {
                ap.color=Color.parseColor("#7C3AED")
                for(i in 0..2){
                    val pulse= abs(sin((aiPhase+i*1.2).toDouble()).toFloat())
                    c.drawCircle(b.centerX()+(i-1)*dp(18f),cy,dp(5f)*(0.4f+0.6f*pulse),ap)
                }
            }
            Mode.HOTSPOT -> {
                tp.textSize=sp(20f); c.drawText("📡",b.left+dp(14f),cy+dp(8f),tp)
                tp.color=Color.WHITE; tp.textSize=sp(13f); c.drawText("Hotspot On",b.left+dp(46f),cy-dp(4f),tp)
                sp2.textSize=sp(11f); c.drawText("$hotDevices connected",b.left+dp(46f),cy+dp(13f),sp2)
            }
            Mode.NAV -> {
                ap.color=Color.parseColor("#007AFF"); tp.textSize=sp(20f); c.drawText("▲",b.left+dp(14f),cy+dp(8f),tp)
                tp.color=Color.WHITE; tp.textSize=sp(13f); c.drawText(navStep,b.left+dp(46f),cy-dp(4f),tp)
                sp2.textSize=sp(11f); c.drawText(navDist,b.left+dp(46f),cy+dp(13f),sp2)
            }
        }
    }

    private fun ex(toW:Float,toH:Float) {
        ValueAnimator.ofFloat(pW,toW).apply{duration=320;interpolator=OvershootInterpolator(1.2f);addUpdateListener{pW=it.animatedValue as Float;invalidate()};start()}
        ValueAnimator.ofFloat(pH,toH).apply{duration=320;interpolator=OvershootInterpolator(1.2f);addUpdateListener{pH=it.animatedValue as Float;invalidate()};start()}
        cAlpha=0f
        ValueAnimator.ofFloat(0f,1f).apply{duration=200;startDelay=200;addUpdateListener{cAlpha=it.animatedValue as Float;invalidate()};start()}
    }

    override fun onTouchEvent(e:MotionEvent):Boolean { return gd.onTouchEvent(e)||super.onTouchEvent(e) }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); h.removeCallbacks(tick) }
    private fun dp(v:Float) = v*resources.displayMetrics.density
    private fun sp(v:Float) = v*resources.displayMetrics.scaledDensity
}
